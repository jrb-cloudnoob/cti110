# Debugging a code file that evaluates different test scores
# 10/24/22
# CTI-110 P3HW1
# Jalen Bond

# (psuedo code goes here!)

# Ask user for input of 6 grades and convert to float numbers
# Place grades in a list called 'all_grades'
# Use the list to determine the Min, Max, Sum, and Average grades
# Display the Min, Max, Sum, and Average grades
# Assign any average grade value greater than or equal to '90' the letter 'A'
# Assign any average grade value greater than or equal to '80' the letter 'B'
# Assign any average grade value greater than or equal to '70' the letter 'C'
# Assign any average grade value greater than or equal to '60' the letter 'D'
# Assign any average grade value less than '60' the letter 'F'
# Evaluate the user's grade and display the result

#INPUT
all_grades = []
all_grades.append(float(input('Enter grade for Module 1: ')))
all_grades.append(float(input('Enter grade for Module 2: ')))
all_grades.append(float(input('Enter grade for Module 3: ')))
all_grades.append(float(input('Enter grade for Module 4: ')))
all_grades.append(float(input('Enter grade for Module 5: ')))
all_grades.append(float(input('Enter grade for Module 6: ')))
print()

                  
avg_grade = sum(all_grades) / len(all_grades)



#PROCESS


if avg_grade >= 90:
    letter_grade = 'A'
elif avg_grade >= 80:
    letter_grade = 'B'
elif avg_grade >= 70:
    letter_grade = 'C'
elif avg_grade >= 60:
    letter_grade = 'D'
else:
    letter_grade = 'F'



#OUTPUT

print('----------Results----------')
print(f'Lowest Grade:       {min(all_grades):.1f}')
print(f'Highest Grade:      {max(all_grades):.1f}')
print(f'Sum of Grades:      {sum(all_grades)}')
print(f'Average:            {avg_grade:.2f}')
print('-----------------------------------------')
print(f'Your grade is:  {letter_grade}')
hold = input()






