# Calculating travel expenses 
# 9/21/2022
# CTI-110 P1HW2 - Travel Expense
# Jalen Bond
#

#(psuedo code goes here!)
#Calculate and display travel expenses
#Enter a string value for travel destination
#Enter a monetary value for gas 
#Enter a monetary value for travel accomodations
#Enter a monetary value for food
#

#Input
print('This program calculates and displays travel expenses')
print()
budget = int(input('Enter budget: > '))
print()
destn = input('Enter your travel destination: > ')
print()
gas = int(input('How much  do you think you will spend on gas?  > '))
print()
accm = int(input('Aproximately, how much do you think you will need for accomodation/hotel? >'))
print()
food = int(input('Last, how much do you need for food? > '))
print()

#Process
expenses = gas + accm + food
remaining_balance = budget - expenses

#Output
print('----------Travel Expenses---------')
print('Location: > ', destn)
print('Initial Budget: > ', budget)
print()
print('Fuel: > ', gas)
print('Accomodation: > ', accm)
print('Food: >', food)
print()
print('Remaining Balance: > ', budget - expenses)
