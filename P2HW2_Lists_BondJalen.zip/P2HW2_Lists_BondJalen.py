# CTI-110
# P2HW2 - List
# Jalen Bond
# 10/10/22
#

#(psuedo code goes here!)

#Store entered values in a single list
#Find the highest grade value in the list
#Find the lowest grade value in the list
#Find the sum of all the values entered in the list
#Enter the grade values for each module on seperate lines
#
#Display the lowest grade value in the list with one decimal point
#Display the highest grade value in the list with one decimal point
#Display the sum of all grade values in the list with one decimal point
#Display the average of all grade values in the list with two decimal points
#



#Input

all_grades = [65.5, 88, 78.5, 90, 61, 92]

highest_grade = max(all_grades) 
lowest_grade = min(all_grades)
sum_grades = sum(all_grades)
avg_grades = sum(all_grades) / len(all_grades)


mod1 =float(input('Enter grade for Module 1: '))
mod2 =float(input('Enter grade for Module 2: '))
mod3 =float(input('Enter grade for Module 3: '))
mod4 =float(input('Enter grade for Module 4: '))
mod5 =float(input('Enter grade for Module 5: '))
mod6 =float(input('Enter grade for Module 6: '))
print()

#Process
sum_grades = mod1 + mod2 + mod3 + mod4 + mod5 + mod6
avg_grades = (mod1 + mod2 + mod3 + mod4 + mod5 + mod6) / 6

#Output

print('----------Results-----------')
print(f'Lowest Grade:       {lowest_grade:.1f}')
print(f'Highest Grade:      {highest_grade:.1f}')
print(f'Sum of Grades:      {sum_grades}')
print(f'Average:            {avg_grades:.2f}')
print('-----------------------------------------')
hold = input()



