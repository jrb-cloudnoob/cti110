def subnum(num1,num2):   # function will ask user to subtract numbers
    guess_count = 0
    correct_guess = False
    answer = num1-num2

    while correct_guess == False:
        print(f'  {num1}')
        print(f'- {num2}')
        print(f'--------')
        print('')
        user_guess = int(input('Enter answer: '))  # Ask user to enter answer

        if user_guess == answer:
            guess_count += 1      # Stores the number of user answer attempts
            print(f'Congratulations!!!! Your answer is correct.....')  # Display message once user gets correct
            print(f'Number of guesses: {guess_count}')     # Display the number of attempts from user
            correct_guess = True
        elif user_guess < answer:
            print('Sorry, guess is too low.\n')    # Display message if answer is too low

            guess_count += 1
        else:
            print('Sorry, guess is too high.\n')    # Display message if answer is too high 
            guess_count += 1
