# A math quiz game with different menu options
# 11/28/20222
# CTI-110 P5HW2 - Math Quiz
# Jalen Bond

import random           # imports random numbers
import MainMenu         # imports main menu
import MathGames        # imports all the math games


stop = False

while stop == False:
    MainMenu.display_menu()

    user_choice = input('Please choose one of the menu options: ')    # Ask user to select a memu option

    if user_choice == '1':
        MathGames.AddGame.addnum(random.randint(1,1000),random.randint(1,1000))
    elif user_choice == '2':
        MathGames.SubtractGame.subnum(random.randint(1,1000),random.randint(1,1000))
    elif user_choice == '3':
        MathGames.MultiplyGame.multiplynum(random.randint(1,1000),random.randint(1,1000))
    elif user_choice == '4':
        stop == True
        user_choice = input('Are you sure? Please type yes or no: ')  # Fail safe built in case user wants to play again
        if user_choice == 'yes':
            print('')
            print('Thank you for playing....')   # Display message if user chooses to exit game
            print('Bye!!!')                      # Display message if user chooses to exit game
            break
        elif user_choice == 'no':
            print('')
            stop == False
    else:
        print('INVALID MENU OPTION!')      # Display message if user enters invalid menu option 
        print('')
        user_choice = input('Please choose one of the menu options: ')
hold = input()








        

















