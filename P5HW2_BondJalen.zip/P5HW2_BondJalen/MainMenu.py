def display_menu():                 # create function for menu
    print('Welcome to Math Quiz')
    print('')
    print('MAIN MENU')
    print('---------------')
    print(f'1. Adding Random Numbers')
    print(f'2. Subtracting Random Numbers')
    print(f'3. Multiplying Random Numbers')
    print(f'4. Exit ')
    print('')

