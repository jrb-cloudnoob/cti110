# CTI-110
# P4HW2 - Salary Calculator
# Jalen Bond
# 11/17/22
#


# PSUEDO CODE GOES HERE

# Ask user to enter name of an employee
# Ask for user to enter number of hours employee worked
# Ask for user to enter the employee pay rate
# Calculate overtime value for hours over 40
# Calculate pay for regular hours
# Calculate gross pay



# INPUT

num_employees = 0
totalOTpay = 0
totalReghrpay = 0
totalGrosspay = 0
othrpay = 0

while True:
    employee_name = input("Enter employee's name or \"None\" to terminate: ")

    if employee_name == "None":  # user input "None" terminates the loop
        break

    hrs_worked = (input("How many hours did "+ employee_name +" work? "))
    payrate = (input("What is "+ employee_name +"'s pay rate? "))

# PROCESS

    try:                                                        # Extra credit function: This ensures that user input is a valid integer
        hrs_worked = float(hrs_worked)
        payrate = float(payrate)

        if hrs_worked > 40:

            othours = float(hrs_worked - 40)
            othrpay += float((payrate*1.5) * othours)
            reghrpay = payrate * 40
            grosspay = othrpay + reghrpay
            num_employees += 1
            totalOTpay += othrpay
            totalReghrpay += reghrpay
            totalGrosspay += grosspay

        else:

            reghrpay = payrate * hrs_worked
            grosspay = reghrpay
            othours = 0
            othrpay = 0
            num_employees += 1
            totalReghrpay += reghrpay
            totalGrosspay += grosspay

# OUTOUT

    #Display employee information

        print()
        print(f'Employee Name: {employee_name}')
        print()
        print('Hours Worked   Pay Rate   OverTime   OverTime Pay   RegHour Pay   Gross Pay   ')
        print('------------------------------------------------------------------------------')
        print(f'{hrs_worked:.2f}   ${payrate:.2f}     {othours:.2f}      ${othrpay:.2f}      ${reghrpay:.2f}        ${grosspay:.2f}')
        print()

    except ValueError:
        print('INVALID!!!!')

# Display number of employees entered
# Display total amount owed in overtime pay
# Display total amount owed in regular hour pay
# Display total amount owed in gross pay


print()
print(f'Total number of employees entered: {num_employees}')
print(f'Total amount payed for overtime: ${totalOTpay:.2f}')
print(f'Total amount payed for regular hours: ${totalReghrpay:.2f}')
print(f'Total amount payed in gross: ${totalGrosspay:.2f}')


    






