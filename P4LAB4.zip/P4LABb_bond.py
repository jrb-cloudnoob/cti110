import turtle             
jb = turtle.Screen()      
t = turtle.Turtle() 


t.shape("turtle")
t.color("red")
jb.bgcolor("black")
t.pensize(8)
t.speed(5)

# START OF FIRST NAME INITIAL
t.penup()
t.back(300)
t.pendown() 
t.fd(140)
t.back(70)
t.right(90)
t.fd(150)
t.circle(-40,180)
t.penup()
t.right(180)
t.circle(40,180)
t.fd(150)
t.right(90)
t.fd(150)
t.left(90)
t.back(200)

# START OF MIDDLE NAME INITIAL
t.pendown()
t.fd(200)
t.right(90)
t.circle(-55,180)
t.right(-135)
t.fd(135)
t.left(45)
t.penup()
t.fd(100)
t.left(90)
t.pendown()

# START OF LAST NAME INITIAL
t.fd(200)
t.right(90)
t.circle(-50,180)
t.circle(50,-180)
t.penup()
t.fd(150)
t.left(90)




# end commands
wn.mainloop()             # Wait for user to close window
