import turtle
win = turtle.Screen()
t = turtle.Turtle()

t.pensize(4)
t.pencolor("black")
t.shape("turtle")
t.speed(3)


t.right(180)

for a in (1,2,3,4):
    t.forward(270)
    t.left(90)


t.right(90)
t.penup()
t.fd(50)
t.left(90)
t.pencolor("red")
t.pendown()

for b in (1,2,3):
    t.forward(270)
    t.right(120)

t.penup()
t.pencolor("black")
t.home()


    

win.mainloop()             
