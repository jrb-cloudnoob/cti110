# CTI-110
# P4HW1 - Score List
# Jalen Bond
# 11-14-22
#

#PSUEDO CODE GOES HERE

# Ask user to reveal how many scores to be entered

# Have user input selected amount of scores

# Everytime a score is entered evaluate if it is valid

# Add each valid score value automatically into a list

# Display the lowest score entered

# Remove the lowest score entered

# Display the modified score list

# Display average score value from modified list

# Determine the letter grade of average score value



#INPUT

num_scores = int(input('How many scores do you want to enter? '))

print()

x = 1

score_list = []




#PROCESS

while x <= num_scores:
    print('Enter score #{}: '.format(x), end= '')
    score = float(input())

    if score < 0 or score > 100:
        print()
        print('INVALID Score entered!!!!')
        print('Score should be between 0 and 100')

    else:
        score_list.append(score)
        x += 1

lowest_score = min(score_list)
score_list.remove(lowest_score)
avg_score = sum(score_list)/len(score_list)

if avg_score >= 90:
    grade = 'A'

elif avg_score >= 80:
    grade = 'B'

elif avg_score >= 70:
    grade = 'C'

else:
    grade = 'F'


#OUTPUT

print()
print()

print('--------------Results--------------')
print(f'Lowest Score :', f'{lowest_score}')
print('Modified List :', score_list)
print('Scores Average:', f'{avg_score: .2f}')
print('Grade         :', grade)
print('-----------------------------------')
hold = input()




