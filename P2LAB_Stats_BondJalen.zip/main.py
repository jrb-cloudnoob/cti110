num1 = float(input())
num2 = float(input())
num3 = float(input())
num4 = float(input())
avg_num = (num1+num2+num3+num4) / 4
your_value = num1*num2*num3*num4

print(f'{your_value:.0f} {avg_num:.0f}')
print(f'{your_value:.3f} {avg_num:.3f}')








