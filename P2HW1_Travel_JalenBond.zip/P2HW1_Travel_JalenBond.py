# Calculating travel expenses using dollar signs & float integers
# 10/5/22
# CTI-110 P2HW1 - Travel
# Jalen Bond



#(psuedo code goes here!)

#Enter a monetary value for budget (budget)
#Enter a string value for travel destination (destn)
#Enter a monetary value for gas (gas)
#Enter a monetary value for travel accomodations (accm)
#Enter a monetary value for food (food)
#Calculate the sum of gas, + food, + accm, to get the monetary value for expenses 
#Calculate the remaining balance by subtracting the monetary value for expenses from the monetary value for budget. 
#Display the string_value for, 'Location'
#Display the monetary value for, 'Initial Budget', as a float
#Display the monetary value for, 'Fuel', as a float
#Display the monetary vale for, 'Food' , as a float
#Display the monetary value for, 'Remaining Balance' , as a float




#Input

print('This program calculates and displays travel expenses')
print()
budget = float(input('Enter budget: > '))
print()
destn =(input('Enter your travel destination: > '))
print()
gas = float(input('How much do you think you will spend on gas?  > '))
print()
accm = float(input('Approximately, how much do you think you will need for accomodation/hotel? > '))
print()
food = float(input('Last, how much do you need for food? > '))
print()
        
#Process

expenses = gas + accm + food
remaining_balance = budget - expenses

#Output

print('----------Travel Expenses---------')
print(f'Location:', destn)
print(f'Initial Budget:         ${budget}')
print()
print(f'Fuel:                   ${gas}')
print(f'Accomodation:           ${accm}')
print(f'Food:                   ${food}')
print('-----------------------------------')
print()
print(f'Remaining Balance:      ${budget - expenses}')
hold = input()
