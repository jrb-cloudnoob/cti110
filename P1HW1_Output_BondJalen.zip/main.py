user_num = int(input('Enter integer:\n'))
print()
print('You entered:', user_num)
print(user_num, 'squared is', user_num*user_num)
print('And', user_num, 'cubed is', user_num**3, '!!')

user_num2 = int(input('Enter another integer:\n'))
print()
addition = user_num + user_num2
multiplication = user_num * user_num2

print(user_num, "+", user_num2, "is", addition)
print(user_num, "*", user_num2, "is", multiplication)