# CTI-110
# P3HW2 - Salary
# Jalen Bond
# 10/31/22
# Creating a program that calculates employee wages based on pay rate and hours worked



# Ask the user to enter their employee name
# Ask the user to enter their number of hours worked
# Ask the user to enter their employee pay rate
# Calculate the amount owed to employee for up to 40 hour 
# Evaluate if the user has worked over 40 hours and calculate amount owed to employee
# Display the total amount owed to employee and call it 'gross pay'
# Display to the user 'Employee Name', 'Pay Rate', "Number of Hours Worked', 'OverTime Hours, OverTime Pay' , 'RegularHour Pay' and 'Gross Pay'



#INPUT

employee_name = input("Enter employee's name: ")
hours = float((input("Enter number of hours worked: ")))
payrate = float((input("Enter employee's pay rate: ")))


#PROCESS


if hours <= 40:
    regularhour_pay = payrate * hours
    overtime_hours = 0
    overtimepay = 0
    grosspay = regularhour_pay

elif hours > 40:
    overtime_hours = float(hours-40)
    overtimepayrate = 1.5 * payrate
    overtimepay = float((payrate*1.5)*overtime_hours)
    regularhour_pay = payrate * 40
    grosspay = overtimepay + regularhour_pay


#OUTPUT

print('------------------------------------')
print(f'Employee Name:     {employee_name}')
print()
print('Hours Worked   Pay Rate     OverTime     OverTime Pay          RegHour Pay       Gross Pay ')
print('---------------------------------------------------------------------------------------------------')
print(f'{hours}           ${payrate}        {overtime_hours}          ${overtimepay}               ${regularhour_pay}            ${grosspay} ')
print('---------------------------------------------------------------------------------------------------')
hold = input()


                                                                            





